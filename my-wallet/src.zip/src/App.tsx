import { useState } from 'react'
import { CreateWallet } from './components/CreateWallet'
import { ImportWallet } from './components/ImportWallet'
import { UnlockWallet } from './components/UnlockWallet'
import { CreateSolanaWallet } from './components/CreateSolanaWallet'
import { UnlockSolanaWallet } from './components/UnlockSolanaWallet'
import { NetworkSwitcher, Network } from './components/NetworkSwitcher'
import { ImportSolanaWallet } from "./components/ImportSalonaWallet";
import ExportPrivateKey from './components/ExportPrivateKey';


function App() {
  const [selectedNetwork, setSelectedNetwork] = useState<Network>('ethereum')

  return (
    <div style={{ padding: '1rem', minWidth: '320px' }}>
      <h2>My Crypto Wallet</h2>

      <NetworkSwitcher selected={selectedNetwork} onChange={setSelectedNetwork} />

      {selectedNetwork === 'ethereum' && (
  <>
    <CreateWallet />
    <ImportWallet />
    <UnlockWallet />
    <ExportPrivateKey chain="ethereum" />
  </>
)}

{selectedNetwork === 'solana' && (
  <>
    <CreateSolanaWallet />
    <ImportSolanaWallet />
    <UnlockSolanaWallet />
    <ExportPrivateKey chain="solana" />
  </>
)}


    </div>
  )
}

export default App
